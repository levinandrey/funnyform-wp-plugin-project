const dob = dobDatepicker(
    '#ff_date',
    {
        display_mode: 'popup'
    }
)